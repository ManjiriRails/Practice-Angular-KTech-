<!-- Links in /docs/documentation should NOT have \`.md\` at the end, because they end up in our wiki at release. -->

# ng add

## Overview
Add support for a library to your project.

## Options
None.
